from django.contrib import admin
from .models import KartuKeluarga, KartuTandaPenduduk

# Register your models here.

admin.site.register(KartuKeluarga)
admin.site.register(KartuTandaPenduduk)