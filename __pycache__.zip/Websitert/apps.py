
from django.apps import AppConfig


class WebsitertConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Websitert'
    verbose_name = 'Website'
