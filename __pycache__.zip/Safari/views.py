from django.shortcuts import render
# from  .models import Websitert


# def home(request):

#     return render(request, 'Websitert/beranda.html')

# def event(request):
#     return render(request, 'event.html')

# def about(request):
#     return render(request, 'tentang-kami.html')

# def fasiltias(request):
#     return render(request, 'fasilitas.html')

# def contact(request):
#     return render(request, 'kontak.html')
